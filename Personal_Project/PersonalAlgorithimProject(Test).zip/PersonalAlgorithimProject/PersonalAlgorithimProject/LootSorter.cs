﻿using System;
using System.Collections.Generic;
using System.Text;


namespace PersonalAlgorithimProject
{
    class LootSorter //Program should help you sort your loot in RPG Games
    {
        //Name of the loot
        public string Exotic = "Exotic Loot";
        public string Legendary = "Legendary Loot";
        public string Rare= "Rare Loot";
        public string Uncommon = "Uncommon Loot";
        public string Common = "Common Loot";

        //Total number of each type of loot that you might have
        public int TotalLoot;
        public int TotalExotic;
        public int TotalLegendary;
        public int TotalRare;
        public int TotalUncommon;
        public int TotalCommon;

        public void ListLoot()//Create a List of all the loot that the player has
        {
            Console.WriteLine("Option 1: This options helps you create a list of the loot");
        }

        public void SortLoot() //Sort all the loot that was created with the list loot
        {
            Console.WriteLine("\nOption 2: This Option will allow the user to sort all the loot they have added");
        }

        public void DeleteLoot() //Delete loot that you don't want in your inventory
        {
            Console.WriteLine("\nOption 3: This Option will allow the user to delete items that they have added to their list");
        }

    }
}
