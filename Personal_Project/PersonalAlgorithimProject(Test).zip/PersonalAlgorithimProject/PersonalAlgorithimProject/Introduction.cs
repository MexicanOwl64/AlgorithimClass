﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PersonalAlgorithimProject
{
    class Introduction
    {
        public void Intro()
        {
            Console.WriteLine("Welcome to RPG Item Sorter: \n" +
                "Pick from the following options to proceed\n");
        }
    }
}
