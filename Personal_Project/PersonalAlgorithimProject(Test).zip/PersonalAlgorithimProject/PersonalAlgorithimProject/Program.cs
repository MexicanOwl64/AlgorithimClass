﻿using System;

namespace PersonalAlgorithimProject
{
    class Program
    {
        static void Main(string[] args)
        {
            LootSorter sort = new LootSorter();
            Introduction intro = new Introduction();
            intro.Intro();
            sort.ListLoot();
            sort.SortLoot();
            sort.DeleteLoot();
        }
    }
}
